using UnityEngine;
using UnityEngine.UI;

public class ToggleHotkey : MonoBehaviour
{
    [Header("Settings")]
    public KeyCode hotkey = KeyCode.Tab;

    [Header("Buttons")]
    public Button openButton;   // �����ð�ť
    public Button closeButton;  // �ر����ð�ť

    private bool isOpen = false; // ��ǰ״̬

    void Update()
    {
        if (Input.GetKeyDown(hotkey))
        {
            if (isOpen)
            {
                // ��ǰ�Ǵ�״̬�������رհ�ť
                if (closeButton != null)
                {
                    closeButton.onClick.Invoke();
                    Debug.Log("Settings closed via hotkey");
                }
            }
            else
            {
                // ��ǰ�ǹر�״̬�������򿪰�ť
                if (openButton != null)
                {
                    openButton.onClick.Invoke();
                    Debug.Log("Settings opened via hotkey");
                }
            }

            // �л�״̬
            isOpen = !isOpen;
        }
    }

    // ����������ǿ������״̬
    public void ForceState(bool open)
    {
        isOpen = open;
    }
}