using UnityEngine;
using UnityEngine.EventSystems;

public class ButtonHoverEffect : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public float normalScale = 1f;
    public float hoverScale = 1.2f;
    public float animationSpeed = 0.2f;

    private Vector3 targetScale;
    private RectTransform _myRect; // �޸��˱����������ױ����ͻ

    void Start()
    {
        // ��ȡ���
        _myRect = GetComponent<RectTransform>();
        targetScale = Vector3.one * normalScale;
    }

    void Update()
    {
        // ƽ������
        if (_myRect != null)
        {
            _myRect.localScale = Vector3.Lerp(_myRect.localScale, targetScale, Time.deltaTime / animationSpeed);
        }
    }

    // ������
    public void OnPointerEnter(PointerEventData eventData)
    {
        targetScale = Vector3.one * hoverScale;
    }

    // ����뿪
    public void OnPointerExit(PointerEventData eventData)
    {
        targetScale = Vector3.one * normalScale;
    }
}